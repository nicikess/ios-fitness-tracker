//
//  DetailViewController.swift
//  EditList
//
//  Created by Andreas on 14.10.19.
//  Copyright © 2019 Andreas Trippel. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    var editViewController: EditViewController? = nil
    
    @IBOutlet weak var firstname: UILabel!
    
    @IBOutlet weak var lastname: UILabel!
    
    @IBOutlet weak var Postalcode: UILabel!
    
   
    var person : Person? = nil

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view
      
    }
    
    override func viewWillAppear(_ animated: Bool) {
        firstname.text = person?.firstName
        lastname.text = person?.lastName
        Postalcode.text = String(person!.plz)
      
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let destinationVC = segue.destination as! EditViewController
        let object = self.person
        destinationVC.person = object
        //controller.navigationItem.leftBarButtonItem = splitViewController?.displayModeButtonItem
        //controller.navigationItem.leftItemsSupplementBackButton = true   
    }
 
}

