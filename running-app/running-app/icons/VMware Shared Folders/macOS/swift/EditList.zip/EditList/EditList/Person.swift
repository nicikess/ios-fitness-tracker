//
//  Person.swift
//  SwiftProgrammers
//
//  Created by Andreas Trippel on 24.09.19.
//  Copyright © 2019 Andreas Trippel. All rights reserved.
//

import Foundation

class Person {
    
    var firstName : String
    var lastName : String
    var plz : Int
    
    init(firstName: String, lastName: String, plz: Int){
        self.firstName = firstName
        self.lastName = lastName
        self.plz = plz        
    }
}


