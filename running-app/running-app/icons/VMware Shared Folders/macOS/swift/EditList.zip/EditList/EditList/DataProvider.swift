//
//  DataProvider.swift
//  SwiftProgrammers
//
//  Created by Andreas Trippel on 24.09.19.
//  Copyright © 2019 Andreas Trippel. All rights reserved.
//

import Foundation

public class DataProvider {
    
    static let sharedInstance = DataProvider()
    
    var memberName : [String]?
    var memberPersons : [Person]?
    
    
    private init() {
        
        //namen
        let memberN: [String] = ["Andreas", "Hans", "Dave", "Anna", "Bettina", "Joana", "Sarah", "Max", "Lisa"]
        
        //personen
        let pers1 = Person (firstName: "Andreas", lastName: "Trippel", plz: 6010)
        let pers2 = Person (firstName: "Hans", lastName: "Müller", plz: 8805)
        let pers3 = Person (firstName: "Dave", lastName: "Blau", plz: 8989)
        let pers4 = Person (firstName: "Anna", lastName: "Grün", plz: 7001)
        let pers5 = Person (firstName: "Bettina", lastName: "Brun", plz: 4021)
        let pers6 = Person (firstName: "Joana", lastName: "Schwarz", plz: 3030)
        let pers7 = Person (firstName: "Sarah", lastName: "Fuchs", plz: 2003)
        let pers8 = Person (firstName: "Max", lastName: "Heusser", plz: 8484)
        let pers9 = Person (firstName: "Lisa", lastName: "Reinle", plz:
            39939)
        
        let persons : [Person] = [pers1, pers2, pers3, pers4, pers5, pers6, pers7, pers8, pers9]
        
        self.memberName = memberN
        self.memberPersons = persons
    }
    
    
    
}
