//
//  EditViewController.swift
//  EditList
//
//  Created by Andreas on 14.10.19.
//  Copyright © 2019 Andreas Trippel. All rights reserved.
//

import UIKit

class EditViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var firstname: UITextField!
    @IBOutlet weak var lastname: UITextField!
    @IBOutlet weak var postalcode: UITextField!
    
    var person : Person? = nil    

    @IBAction func saveAndExitButtonPressed(_ sender: Any) {
        
        let pers = DataProvider.sharedInstance.memberPersons
        var index = 0
        
        let firstName = firstname.text!
        let lastName = lastname.text!
        let postalCode = Int(postalcode.text!)
        
        for Person in pers!
        {
            if Person === person{
                break
            }
            
            index += 1
        }
        
        let newPers = DataProvider.sharedInstance.memberPersons![index]
        var newName = DataProvider.sharedInstance.memberName![index]
        
        newPers.firstName = firstName
        newPers.lastName = lastName
        newPers.plz = postalCode!
        
        newName = firstName
        
        DataProvider.sharedInstance.memberName![index] = newName
        DataProvider.sharedInstance.memberPersons![index] = newPers
        
        dismiss(animated: true, completion: nil)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.firstname.delegate = self
        self.lastname.delegate = self
        self.postalcode.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {        
        firstname.text = person?.firstName
        lastname.text = person?.lastName
        let zipCode = person!.plz
        let zipCodeString = String(zipCode)
        postalcode.text = zipCodeString
    }
    

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
