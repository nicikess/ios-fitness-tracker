//
//  ViewController.swift
//  ComAndCon
//
//  Created by Andreas on 22.10.19.
//  Copyright © 2019 Andreas Trippel. All rights reserved.
//
import Vision
import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource{
    
    @IBOutlet weak var picker: UIPickerView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var pictureRecognition: UILabel!
    
    let url = URL(string : "https://hslu.nitschi.ch/networking/data.json")
    
    var images: [ImageInfo]?
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        pictureRecognition.text = ""
        
        images = loadListSync()
        
        picker.delegate = self
        picker.dataSource = self
        
        DispatchQueue.global(qos: .default).async {
            let image : UIImage = self.loadImageSync(image: self.images![0])!
            
            var reco : String?
            
            self.classifyImageAsync(image : image) { (String) in
               reco = String!
            self.pictureRecognition.text = reco!
            }
            
            DispatchQueue.main.async {
                self.imageView.image = image
                self.titleLabel.text = self.images?[0].title
               
            }
        }
    }
    
   

    func loadListSync() -> [ImageInfo]?{
        
        var imageInfo : Response?
        var images : [ImageInfo]?
        
        do {
            let response =  try Data(contentsOf: url!)
            
            imageInfo = try JSONDecoder().decode(Response.self, from: response)
            images = imageInfo?.images
            
        } catch {
            print(error)
        }
        return images
    }
     
    func loadImageSync(image: ImageInfo) -> UIImage?{
        
        var bild : UIImage?
        
        do {
            bild = try UIImage(data: Data(contentsOf: image.url))!
            
        } catch {
            print(error)
        }
        return bild
    }
     
    func loadImageAsync(image: ImageInfo, completion: @escaping
    (UIImage?)->Void){
        
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
           return 1
       }
       
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return images!.count
       }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return images![row].title
            }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        titleLabel.text = images![row].title
        pictureRecognition.text = ""
        
        let myQueue = DispatchQueue(label: "loadImage")
        
        myQueue.async {
            let image : UIImage = self.loadImageSync(image: self.images![row])!
            
            var reco : String?
            self.classifyImageAsync(image: image) { (String) in
            print(String!)
            reco = String!
            self.pictureRecognition.text = reco!
                      }
            
            DispatchQueue.main.async {
                self.imageView.image = image
            }
        }
    }
    

    // Use the new iOS 13 image classification
    // dont forget to 'import Vision'
    func classifyImageAsync(image: UIImage?, completion: @escaping (String?)->Void) {
    DispatchQueue.global().async {
    guard let cgImage = image?.cgImage else {
    DispatchQueue.main.async {
    completion(nil) }
    return
    }
    // create a image request handler
    let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
    // perform a classify-request
    try? handler.perform([VNClassifyImageRequest( completionHandler: { (request, error) in
    // Use the full power of swift: If there are results (0), take only the classifications and filter everything else (1), then filter for a confidence greater 0.8 (2), extract the identifier strings (3) and join them to a comma- separated list (4)
    let topResults = request.results? // 0
        .compactMap { $0 as? VNClassificationObservation } // 1
        .filter { $0.confidence > 0.8 } //2
        .map { $0.identifier } // 3 .
        .joined(separator: ", ") // 4
    DispatchQueue.main.async { completion(topResults)
    }
     })]) }
    }
}


struct Response: Codable {
  let images: [ImageInfo]
  
  let lastUpdate: Date
  let info: String
 }
  
 struct ImageInfo: Codable {
  let identifier: Int
  let title: String
  let text: String
  let url: URL
 }

